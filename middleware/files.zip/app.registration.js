// src/app.js  — UPDATED SNIPPET (route registration section only)
//
// Add the users router alongside the existing auth router.
// The rest of app.js (helmet, cors, rate-limit, error handler) is unchanged.
//
// ─── BEFORE ──────────────────────────────────────────────────────────────────
//
//   import authRoutes  from "./modules/auth/auth.routes.js";
//   ...
//   app.use("/api/auth",  authRoutes);
//
// ─── AFTER ───────────────────────────────────────────────────────────────────

import authRoutes  from "./modules/auth/auth.routes.js";
import usersRoutes from "./modules/users/users.routes.js";

// ... (helmet, cors, rate-limit middleware setup remains above this line)

app.use("/api/auth",  authRoutes);
app.use("/api/users", usersRoutes);   // ← ADD THIS LINE

// ... (global error handler remains below this line)
