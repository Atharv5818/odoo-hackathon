// src/pages/TripDetail.jsx
// Main trip workspace. Loads the trip, then renders a tab-based layout.
// The Itinerary tab reuses the existing ItineraryTab component.
// All other tabs are implemented here using the module components above.

import { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate }            from "react-router-dom";
import {
  LayoutDashboard, Map, DollarSign, CheckSquare, BookOpen,
} from "lucide-react";

// Trip UI components
import TripHeader        from "../components/trips/TripHeader";
import TripOverviewStats from "../components/trips/TripOverviewStats";

// Budget components
import BudgetSummaryCard    from "../components/budget/BudgetSummaryCard";
import BudgetCategoryChart  from "../components/budget/BudgetCategoryChart";
import BudgetItemList       from "../components/budget/BudgetItemList";

// Notes components
import NoteCard      from "../components/notes/NoteCard";
import NotesComposer from "../components/notes/NotesComposer";

// Checklist components
import ChecklistGroup from "../components/checklist/ChecklistGroup";

// Existing itinerary tab (already built in Phase 4)
// import ItineraryTab from "../components/itinerary/ItineraryTab";

// API layer — reuse existing services
import {
  tripsAPI, budgetAPI, checklistAPI, notesAPI,
} from "../services/api";

// ─── SKELETON ─────────────────────────────────────────────────────────────────
function Skeleton({ className }) {
  return <div className={`bg-stone-200/70 animate-pulse rounded-xl ${className}`} />;
}

function PageSkeleton() {
  return (
    <div className="space-y-4 p-6">
      <Skeleton className="h-44 rounded-3xl" />
      <div className="grid grid-cols-4 gap-3">
        {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-20" />)}
      </div>
    </div>
  );
}

// ─── TAB NAV ──────────────────────────────────────────────────────────────────
const TABS = [
  { id: "overview",   label: "Overview",   icon: LayoutDashboard },
  { id: "itinerary",  label: "Itinerary",  icon: Map             },
  { id: "budget",     label: "Budget",     icon: DollarSign      },
  { id: "checklist",  label: "Checklist",  icon: CheckSquare     },
  { id: "notes",      label: "Notes",      icon: BookOpen        },
];

function TabNav({ active, onChange }) {
  return (
    <div className="flex items-center gap-1 bg-stone-100/80 backdrop-blur-sm p-1 rounded-2xl w-fit mb-6 flex-wrap">
      {TABS.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-150 ${
            active === id
              ? "bg-white text-stone-800 shadow-sm"
              : "text-stone-500 hover:text-stone-700 hover:bg-stone-50"
          }`}
        >
          <Icon size={14} />
          {label}
        </button>
      ))}
    </div>
  );
}

// ─── OVERVIEW TAB ─────────────────────────────────────────────────────────────
function OverviewTab({ trip, budgetSummary }) {
  return (
    <div className="space-y-5">
      <TripOverviewStats trip={trip} />

      {trip.description && (
        <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl p-5">
          <h3 className="text-stone-500 text-xs font-semibold uppercase tracking-wider mb-2">About this trip</h3>
          <p className="text-stone-700 text-sm leading-relaxed">{trip.description}</p>
        </div>
      )}

      {budgetSummary && (
        <BudgetSummaryCard
          totalBudget={budgetSummary.totalBudget}
          totalSpent={budgetSummary.totalSpent}
          currency={trip.currency ?? "USD"}
        />
      )}
    </div>
  );
}

// ─── BUDGET TAB ───────────────────────────────────────────────────────────────
function BudgetTab({ tripId, currency = "USD" }) {
  const [summary,    setSummary]    = useState(null);
  const [items,      setItems]      = useState([]);
  const [loading,    setLoading]    = useState(true);
  const [addForm,    setAddForm]    = useState({ title: "", amount: "", category: "other" });
  const [adding,     setAdding]     = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [sumRes, itemsRes] = await Promise.all([
        budgetAPI.getSummary(tripId),
        budgetAPI.getItems(tripId),
      ]);
      setSummary(sumRes.data?.data ?? sumRes.data);
      setItems(itemsRes.data?.data?.items ?? itemsRes.data?.items ?? []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [tripId]);

  useEffect(() => { load(); }, [load]);

  const handleAdd = async () => {
    if (!addForm.title.trim() || !addForm.amount) return;
    setAdding(true);
    try {
      await budgetAPI.addItem(tripId, {
        title:    addForm.title.trim(),
        amount:   parseFloat(addForm.amount),
        category: addForm.category,
      });
      setAddForm({ title: "", amount: "", category: "other" });
      await load();
    } finally {
      setAdding(false);
    }
  };

  const handleDelete = async (id) => {
    setItems((prev) => prev.filter((i) => i.id !== id)); // optimistic
    try { await budgetAPI.deleteItem(tripId, id); }
    catch { load(); }
  };

  const categories = Object.entries(
    items.reduce((acc, i) => {
      const k = i.category ?? "other";
      acc[k] = (acc[k] ?? 0) + (i.amount ?? 0);
      return acc;
    }, {})
  ).map(([name, amount]) => ({ name, amount }));

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {summary && (
        <BudgetSummaryCard
          totalBudget={summary.totalBudget}
          totalSpent={summary.totalSpent}
          currency={currency}
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <BudgetCategoryChart categories={categories} currency={currency} />

        {/* Add expense form */}
        <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl p-5">
          <h3 className="text-stone-700 font-semibold text-sm mb-4">Add Expense</h3>
          <div className="space-y-3">
            <input
              type="text"
              placeholder="Description"
              value={addForm.title}
              onChange={(e) => setAddForm((f) => ({ ...f, title: e.target.value }))}
              className="w-full text-sm bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 focus:outline-none focus:border-amber-300"
            />
            <div className="flex gap-2">
              <input
                type="number"
                placeholder="Amount"
                value={addForm.amount}
                onChange={(e) => setAddForm((f) => ({ ...f, amount: e.target.value }))}
                className="flex-1 text-sm bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 focus:outline-none focus:border-amber-300"
              />
              <select
                value={addForm.category}
                onChange={(e) => setAddForm((f) => ({ ...f, category: e.target.value }))}
                className="flex-1 text-sm bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 focus:outline-none focus:border-amber-300"
              >
                {["accommodation","food","transport","activities","shopping","other"].map((c) => (
                  <option key={c} value={c}>{c.charAt(0).toUpperCase() + c.slice(1)}</option>
                ))}
              </select>
            </div>
            <button
              onClick={handleAdd}
              disabled={!addForm.title.trim() || !addForm.amount || adding}
              className="w-full bg-amber-500 hover:bg-amber-600 disabled:opacity-40 text-white text-sm font-medium py-2.5 rounded-xl transition-colors"
            >
              {adding ? "Adding…" : "Add Expense"}
            </button>
          </div>
        </div>
      </div>

      <BudgetItemList items={items} onDelete={handleDelete} currency={currency} />
    </div>
  );
}

// ─── CHECKLIST TAB ────────────────────────────────────────────────────────────
function ChecklistTab({ tripId }) {
  const [groups,  setGroups]  = useState([]);
  const [loading, setLoading] = useState(true);
  const [newGroup, setNewGroup] = useState("");
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await checklistAPI.getGroups(tripId);
      setGroups(res.data?.data?.groups ?? res.data?.groups ?? []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [tripId]);

  useEffect(() => { load(); }, [load]);

  const handleToggle = async (itemId, isCompleted) => {
    // Optimistic update
    setGroups((prev) =>
      prev.map((g) => ({
        ...g,
        items: g.items.map((i) => i.id === itemId ? { ...i, isCompleted } : i),
      }))
    );
    try { await checklistAPI.toggleItem(tripId, itemId, { isCompleted }); }
    catch { load(); }
  };

  const handleDeleteItem = async (itemId) => {
    setGroups((prev) =>
      prev.map((g) => ({ ...g, items: g.items.filter((i) => i.id !== itemId) }))
    );
    try { await checklistAPI.deleteItem(tripId, itemId); }
    catch { load(); }
  };

  const handleAddItem = async (groupId, title) => {
    const res = await checklistAPI.addItem(tripId, groupId, { title });
    const newItem = res.data?.data?.item ?? res.data?.item;
    setGroups((prev) =>
      prev.map((g) => g.id === groupId ? { ...g, items: [...g.items, newItem] } : g)
    );
  };

  const handleCreateGroup = async () => {
    const t = newGroup.trim();
    if (!t) return;
    setCreating(true);
    try {
      await checklistAPI.createGroup(tripId, { title: t });
      setNewGroup("");
      await load();
    } finally { setCreating(false); }
  };

  const totalItems = groups.reduce((s, g) => s + (g.items?.length ?? 0), 0);
  const doneItems  = groups.reduce((s, g) => s + (g.items?.filter((i) => i.isCompleted).length ?? 0), 0);

  if (loading) {
    return <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20" />)}</div>;
  }

  return (
    <div className="space-y-4">
      {/* Overall progress */}
      {totalItems > 0 && (
        <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl px-5 py-3 flex items-center gap-4">
          <div className="flex-1 h-2 bg-stone-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-emerald-400 rounded-full transition-all duration-500"
              style={{ width: `${Math.round((doneItems / totalItems) * 100)}%` }}
            />
          </div>
          <span className="text-sm text-stone-600 font-medium flex-shrink-0">
            {doneItems} / {totalItems} done
          </span>
        </div>
      )}

      {groups.length === 0 && (
        <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl p-10 text-center">
          <CheckSquare size={28} className="text-stone-300 mx-auto mb-2" />
          <p className="text-stone-400 text-sm font-medium">No checklists yet</p>
          <p className="text-stone-300 text-xs mt-1">Create a group to get started</p>
        </div>
      )}

      {groups.map((g) => (
        <ChecklistGroup
          key={g.id}
          group={g}
          onToggle={handleToggle}
          onDelete={handleDeleteItem}
          onAddItem={handleAddItem}
        />
      ))}

      {/* Add group */}
      <div className="flex gap-2">
        <input
          type="text"
          placeholder="New checklist group…"
          value={newGroup}
          onChange={(e) => setNewGroup(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleCreateGroup()}
          className="flex-1 text-sm bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-xl px-4 py-2.5 focus:outline-none focus:border-amber-300"
        />
        <button
          onClick={handleCreateGroup}
          disabled={!newGroup.trim() || creating}
          className="bg-amber-500 hover:bg-amber-600 disabled:opacity-40 text-white text-sm font-medium px-4 py-2.5 rounded-xl transition-colors"
        >
          {creating ? "…" : "Add group"}
        </button>
      </div>
    </div>
  );
}

// ─── NOTES TAB ────────────────────────────────────────────────────────────────
function NotesTab({ tripId }) {
  const [notes,   setNotes]   = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await notesAPI.getNotes(tripId);
      setNotes(res.data?.data?.notes ?? res.data?.notes ?? []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [tripId]);

  useEffect(() => { load(); }, [load]);

  const handleAdd = async (content) => {
    const res = await notesAPI.createNote(tripId, { content });
    const note = res.data?.data?.note ?? res.data?.note;
    setNotes((prev) => [note, ...prev]);
  };

  const handleUpdate = async (noteId, data) => {
    await notesAPI.updateNote(tripId, noteId, data);
    setNotes((prev) => prev.map((n) => n.id === noteId ? { ...n, ...data } : n));
  };

  const handleDelete = async (noteId) => {
    setNotes((prev) => prev.filter((n) => n.id !== noteId)); // optimistic
    try { await notesAPI.deleteNote(tripId, noteId); }
    catch { load(); }
  };

  if (loading) {
    return <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-24" />)}</div>;
  }

  return (
    <div className="space-y-4">
      <NotesComposer onAdd={handleAdd} />

      {notes.length === 0 && (
        <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl p-10 text-center">
          <BookOpen size={28} className="text-stone-300 mx-auto mb-2" />
          <p className="text-stone-400 text-sm font-medium">No notes yet</p>
          <p className="text-stone-300 text-xs mt-1">Start capturing your trip thoughts above</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {notes.map((note) => (
          <NoteCard key={note.id} note={note} onDelete={handleDelete} onUpdate={handleUpdate} />
        ))}
      </div>
    </div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────
export default function TripDetail() {
  const { tripId }          = useParams();
  const navigate            = useNavigate();
  const [trip,     setTrip] = useState(null);
  const [budget,   setBudget] = useState(null);
  const [loading,  setLoading] = useState(true);
  const [error,    setError]  = useState(null);
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [tripRes, budgetRes] = await Promise.allSettled([
          tripsAPI.getTrip(tripId),
          budgetAPI.getSummary(tripId),
        ]);

        if (tripRes.status === "fulfilled") {
          setTrip(tripRes.value.data?.data?.trip ?? tripRes.value.data?.trip ?? tripRes.value.data);
        } else {
          setError("Trip not found.");
        }

        if (budgetRes.status === "fulfilled") {
          setBudget(budgetRes.value.data?.data ?? budgetRes.value.data);
        }
      } catch (e) {
        setError("Failed to load trip.");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [tripId]);

  if (loading) return <PageSkeleton />;

  if (error || !trip) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[40vh] text-center p-8">
        <p className="text-stone-500 text-sm mb-4">{error ?? "Trip not found."}</p>
        <button
          onClick={() => navigate("/dashboard")}
          className="text-amber-600 text-sm font-medium hover:underline"
        >
          ← Back to dashboard
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-50 via-amber-50/20 to-stone-100 p-4 md:p-6">
      <div className="max-w-5xl mx-auto">
        <TripHeader trip={trip} />
        <TabNav active={activeTab} onChange={setActiveTab} />

        {activeTab === "overview"  && <OverviewTab trip={trip} budgetSummary={budget} />}
        {activeTab === "itinerary" && (
          <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl p-5">
            {/* Mount existing ItineraryTab here: <ItineraryTab tripId={tripId} /> */}
            <p className="text-stone-400 text-sm text-center py-8">
              Itinerary tab — mount existing <code className="bg-stone-100 px-1 rounded">ItineraryTab</code> component here.
            </p>
          </div>
        )}
        {activeTab === "budget"    && <BudgetTab    tripId={tripId} currency={trip.currency ?? "USD"} />}
        {activeTab === "checklist" && <ChecklistTab tripId={tripId} />}
        {activeTab === "notes"     && <NotesTab     tripId={tripId} />}
      </div>
    </div>
  );
}
