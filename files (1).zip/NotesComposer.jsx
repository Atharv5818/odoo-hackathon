// src/components/notes/NotesComposer.jsx
import { useState } from "react";
import { PenLine, Send } from "lucide-react";

export default function NotesComposer({ onAdd, placeholder = "Write a note…" }) {
  const [value,    setValue]    = useState("");
  const [focused,  setFocused]  = useState(false);
  const [loading,  setLoading]  = useState(false);

  const handleSubmit = async () => {
    const trimmed = value.trim();
    if (!trimmed) return;
    setLoading(true);
    try {
      await onAdd?.(trimmed);
      setValue("");
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) handleSubmit();
  };

  return (
    <div
      className={`bg-white/70 backdrop-blur-sm border rounded-2xl transition-all duration-200 ${
        focused ? "border-amber-300 shadow-[0_0_0_3px_rgba(251,191,36,0.15)]" : "border-stone-200/80"
      }`}
    >
      <div className="flex items-start gap-3 p-4">
        <div className="w-7 h-7 rounded-lg bg-amber-100 flex items-center justify-center flex-shrink-0 mt-0.5">
          <PenLine size={13} className="text-amber-600" />
        </div>
        <textarea
          className="flex-1 text-sm text-stone-700 placeholder-stone-300 bg-transparent resize-none focus:outline-none leading-relaxed min-h-[60px]"
          placeholder={placeholder}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          onKeyDown={handleKey}
        />
      </div>
      {(focused || value) && (
        <div className="flex items-center justify-between px-4 pb-3 pt-0">
          <p className="text-xs text-stone-300">⌘↩ to save</p>
          <button
            onClick={handleSubmit}
            disabled={!value.trim() || loading}
            className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 disabled:opacity-40 text-white text-xs font-medium px-3 py-1.5 rounded-xl transition-colors"
          >
            <Send size={12} />
            {loading ? "Adding…" : "Add note"}
          </button>
        </div>
      )}
    </div>
  );
}
