// src/components/budget/BudgetCategoryChart.jsx
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";

const PALETTE = [
  "#f59e0b", "#10b981", "#3b82f6", "#8b5cf6",
  "#ec4899", "#f97316", "#06b6d4", "#84cc16",
];

const CustomTooltip = ({ active, payload, currency = "USD" }) => {
  if (!active || !payload?.length) return null;
  const { name, value } = payload[0];
  const fmt = (n) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency, maximumFractionDigits: 0 }).format(n);
  return (
    <div className="bg-white border border-stone-200 rounded-xl shadow-lg px-3 py-2 text-sm">
      <p className="font-semibold text-stone-700">{name}</p>
      <p className="text-amber-600 font-bold">{fmt(value)}</p>
    </div>
  );
};

export default function BudgetCategoryChart({ categories = [], currency = "USD" }) {
  const data = categories.map((c) => ({ name: c.name, value: c.amount }));

  if (!data.length) {
    return (
      <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl p-5 flex items-center justify-center h-52">
        <p className="text-stone-400 text-sm">No category data yet</p>
      </div>
    );
  }

  return (
    <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl p-5">
      <h3 className="text-stone-700 font-semibold text-sm mb-4">Spending by Category</h3>
      <ResponsiveContainer width="100%" height={220}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={55}
            outerRadius={85}
            paddingAngle={3}
            dataKey="value"
          >
            {data.map((_, i) => (
              <Cell key={i} fill={PALETTE[i % PALETTE.length]} stroke="none" />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip currency={currency} />} />
          <Legend
            formatter={(value) => (
              <span className="text-xs text-stone-600 font-medium">{value}</span>
            )}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
