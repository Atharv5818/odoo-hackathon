// src/pages/PublicShare.jsx
// Public read-only trip showcase. Accessible without authentication.
// Loaded via slug: /share/:slug
// Designed to feel like a travel editorial — rich, visual, no editing controls.

import { useState, useEffect } from "react";
import { useParams }           from "react-router-dom";
import { MapPin, Calendar, Clock, ArrowRight } from "lucide-react";
import { sharingAPI }          from "../services/api";

// ─── COVER HERO ───────────────────────────────────────────────────────────────
const GRADIENTS = [
  ["from-amber-500 via-orange-400 to-rose-400",   "text-amber-100"],
  ["from-sky-500 via-cyan-400 to-teal-400",       "text-sky-100"  ],
  ["from-violet-500 via-purple-400 to-pink-400",  "text-violet-100"],
  ["from-emerald-500 via-green-400 to-teal-400",  "text-emerald-100"],
];

function pickGradient(seed = "") {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = seed.charCodeAt(i) + ((h << 5) - h);
  return GRADIENTS[Math.abs(h) % GRADIENTS.length];
}

function Hero({ trip }) {
  const [grad, accent] = pickGradient(trip.id ?? trip.title);
  const fmt = (d) =>
    d ? new Date(d).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }) : null;

  return (
    <div className={`relative min-h-[42vh] bg-gradient-to-br ${grad} flex flex-col justify-end overflow-hidden`}>
      {/* Texture overlay */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: "radial-gradient(circle at 1px 1px, white 1px, transparent 0)",
          backgroundSize: "24px 24px",
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />

      <div className="relative z-10 px-6 md:px-12 pb-10 pt-24">
        <div className="flex items-center gap-2 mb-3">
          <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-widest">
            Trip Itinerary
          </span>
        </div>

        <h1
          className="text-white font-bold leading-tight mb-3"
          style={{
            fontFamily: "'Fraunces', serif",
            fontSize: "clamp(2rem, 5vw, 3.5rem)",
          }}
        >
          {trip.title}
        </h1>

        <div className="flex flex-wrap items-center gap-4 text-white/80 text-sm">
          {trip.destination && (
            <span className="flex items-center gap-1.5">
              <MapPin size={14} />
              {trip.destination}
            </span>
          )}
          {trip.startDate && (
            <span className="flex items-center gap-1.5">
              <Calendar size={14} />
              {fmt(trip.startDate)}
              {trip.endDate && (
                <>
                  <ArrowRight size={12} />
                  {fmt(trip.endDate)}
                </>
              )}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── STOP CARD ────────────────────────────────────────────────────────────────
function StopCard({ stop, index }) {
  return (
    <div className="flex gap-4 group">
      {/* Timeline */}
      <div className="flex flex-col items-center">
        <div className="w-8 h-8 rounded-full bg-amber-100 border-2 border-amber-300 flex items-center justify-center flex-shrink-0 text-xs font-bold text-amber-700">
          {index + 1}
        </div>
        <div className="w-0.5 flex-1 bg-stone-200 mt-2 mb-0 min-h-[24px]" />
      </div>

      {/* Content */}
      <div className="pb-6 flex-1 min-w-0">
        <div className="bg-white/80 backdrop-blur-sm border border-stone-200/80 rounded-2xl p-4 shadow-sm">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3 className="font-semibold text-stone-800 text-sm leading-tight">{stop.title}</h3>
            {stop.startTime && (
              <span className="flex items-center gap-1 text-xs text-stone-400 flex-shrink-0">
                <Clock size={11} />
                {stop.startTime}
              </span>
            )}
          </div>
          {stop.location && (
            <p className="flex items-center gap-1 text-xs text-stone-400 mb-1.5">
              <MapPin size={10} />
              {stop.location}
            </p>
          )}
          {stop.description && (
            <p className="text-stone-600 text-xs leading-relaxed">{stop.description}</p>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── DAY SECTION ──────────────────────────────────────────────────────────────
function DaySection({ day }) {
  const fmt = (d) =>
    d ? new Date(d).toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" }) : null;

  return (
    <div className="mb-8">
      <div className="flex items-center gap-3 mb-4">
        <div className="h-px flex-1 bg-stone-200" />
        <div className="bg-stone-100 text-stone-600 text-xs font-semibold px-4 py-1.5 rounded-full uppercase tracking-wider">
          Day {day.dayNumber} {day.date ? `· ${fmt(day.date)}` : ""}
        </div>
        <div className="h-px flex-1 bg-stone-200" />
      </div>

      {day.stops?.length ? (
        <div>
          {day.stops.map((stop, i) => (
            <StopCard key={stop.id ?? i} stop={stop} index={i} />
          ))}
        </div>
      ) : (
        <p className="text-stone-300 text-sm text-center py-4">Nothing planned yet</p>
      )}
    </div>
  );
}

// ─── LOADING / ERROR ─────────────────────────────────────────────────────────
function LoadingSkeleton() {
  return (
    <div>
      <div className="h-[42vh] bg-gradient-to-br from-stone-200 to-stone-300 animate-pulse" />
      <div className="max-w-2xl mx-auto px-6 py-10 space-y-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-20 bg-stone-100 animate-pulse rounded-2xl" />
        ))}
      </div>
    </div>
  );
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────
export default function PublicShare() {
  const { slug }              = useParams();
  const [data,    setData]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const res = await sharingAPI.getPublicTrip(slug);
        setData(res.data?.data ?? res.data);
      } catch (e) {
        setError(e.response?.status === 404 ? "This itinerary isn't available." : "Something went wrong.");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [slug]);

  if (loading) return <LoadingSkeleton />;

  if (error || !data) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center p-6 text-center">
        <div>
          <p className="text-4xl mb-4">✈️</p>
          <h2
            className="text-2xl font-bold text-stone-700 mb-2"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            Itinerary not found
          </h2>
          <p className="text-stone-400 text-sm">{error ?? "This link may have expired."}</p>
        </div>
      </div>
    );
  }

  const { trip, itinerary } = data;
  const days = itinerary?.days ?? [];

  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-50 to-white">
      <Hero trip={trip} />

      <div className="max-w-2xl mx-auto px-4 md:px-6 py-10">
        {trip.description && (
          <div className="mb-10 pb-8 border-b border-stone-100">
            <p className="text-stone-600 leading-relaxed text-base italic">
              {trip.description}
            </p>
          </div>
        )}

        {days.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-5xl mb-4">🗺️</p>
            <p
              className="text-xl font-bold text-stone-600 mb-1"
              style={{ fontFamily: "'Fraunces', serif" }}
            >
              Itinerary coming soon
            </p>
            <p className="text-stone-400 text-sm">The traveler is still planning this trip.</p>
          </div>
        ) : (
          days.map((day) => (
            <DaySection key={day.id ?? day.dayNumber} day={day} />
          ))
        )}

        {/* Footer */}
        <div className="mt-12 pt-8 border-t border-stone-100 text-center">
          <p className="text-xs text-stone-300">
            Created with{" "}
            <span
              className="font-semibold text-amber-500"
              style={{ fontFamily: "'Fraunces', serif" }}
            >
              Traveloop
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}
