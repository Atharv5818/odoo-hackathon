// src/components/trips/TripHeader.jsx
import TripStatusBadge from "./TripStatusBadge";
import { MapPin, Share2, MoreHorizontal } from "lucide-react";

// Deterministic cover gradient based on trip id/title so each trip feels unique
const GRADIENTS = [
  "from-amber-400 via-orange-300 to-rose-300",
  "from-sky-400 via-cyan-300 to-teal-300",
  "from-violet-400 via-purple-300 to-pink-300",
  "from-emerald-400 via-green-300 to-teal-300",
  "from-rose-400 via-pink-300 to-fuchsia-300",
];

function pickGradient(seed = "") {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash = seed.charCodeAt(i) + ((hash << 5) - hash);
  return GRADIENTS[Math.abs(hash) % GRADIENTS.length];
}

export default function TripHeader({ trip, onShare, onOptions }) {
  const gradient = pickGradient(trip?.id ?? trip?.title ?? "");
  const fmt = (d) =>
    d ? new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : null;

  return (
    <div className="relative rounded-3xl overflow-hidden mb-6 shadow-lg">
      {/* Cover */}
      <div className={`h-44 bg-gradient-to-br ${gradient} relative`}>
        <div className="absolute inset-0 bg-black/10" />

        {/* Action buttons */}
        <div className="absolute top-4 right-4 flex gap-2">
          {onShare && (
            <button
              onClick={onShare}
              className="flex items-center gap-1.5 bg-white/20 backdrop-blur-sm text-white text-sm px-3 py-1.5 rounded-xl hover:bg-white/30 transition-colors"
            >
              <Share2 size={14} />
              Share
            </button>
          )}
          {onOptions && (
            <button
              onClick={onOptions}
              className="bg-white/20 backdrop-blur-sm text-white p-1.5 rounded-xl hover:bg-white/30 transition-colors"
            >
              <MoreHorizontal size={16} />
            </button>
          )}
        </div>
      </div>

      {/* Info bar */}
      <div className="bg-white/80 backdrop-blur-sm border-t border-stone-100 px-6 py-4 flex items-start justify-between gap-4 flex-wrap">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <TripStatusBadge status={trip?.status} size="sm" />
          </div>
          <h1
            className="font-display text-2xl font-bold text-stone-800 leading-tight"
            style={{ fontFamily: "'Fraunces', serif" }}
          >
            {trip?.title ?? "Untitled Trip"}
          </h1>
          {trip?.destination && (
            <p className="flex items-center gap-1 text-stone-500 text-sm mt-0.5">
              <MapPin size={13} className="text-amber-500" />
              {trip.destination}
            </p>
          )}
        </div>

        {trip?.startDate && (
          <div className="text-right flex-shrink-0">
            <p className="text-xs text-stone-400 uppercase tracking-wider font-medium">Travel dates</p>
            <p className="text-stone-700 text-sm font-semibold mt-0.5">
              {fmt(trip.startDate)}
              {trip.endDate && ` → ${fmt(trip.endDate)}`}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
