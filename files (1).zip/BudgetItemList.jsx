// src/components/budget/BudgetItemList.jsx
import { Trash2, Receipt } from "lucide-react";

const CATEGORY_COLORS = {
  accommodation: "bg-sky-100 text-sky-700",
  food:          "bg-amber-100 text-amber-700",
  transport:     "bg-violet-100 text-violet-700",
  activities:    "bg-emerald-100 text-emerald-700",
  shopping:      "bg-pink-100 text-pink-700",
  other:         "bg-stone-100 text-stone-600",
};

function categoryStyle(cat) {
  return CATEGORY_COLORS[cat?.toLowerCase()] ?? CATEGORY_COLORS.other;
}

export default function BudgetItemList({ items = [], onDelete, currency = "USD" }) {
  const fmt = (n) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency, maximumFractionDigits: 2 }).format(n ?? 0);

  if (!items.length) {
    return (
      <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl p-8 text-center">
        <Receipt size={28} className="text-stone-300 mx-auto mb-2" />
        <p className="text-stone-400 text-sm font-medium">No expenses yet</p>
        <p className="text-stone-300 text-xs mt-1">Add your first expense above</p>
      </div>
    );
  }

  return (
    <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl overflow-hidden">
      <div className="px-5 py-3 border-b border-stone-100">
        <h3 className="text-stone-700 font-semibold text-sm">Expenses</h3>
      </div>
      <ul className="divide-y divide-stone-50">
        {items.map((item) => (
          <li key={item.id} className="flex items-center justify-between px-5 py-3 hover:bg-stone-50/60 transition-colors group">
            <div className="flex items-center gap-3 min-w-0">
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full flex-shrink-0 ${categoryStyle(item.category)}`}>
                {item.category ?? "Other"}
              </span>
              <p className="text-stone-700 text-sm truncate">{item.title ?? item.description}</p>
            </div>
            <div className="flex items-center gap-3 flex-shrink-0 ml-2">
              <span className="text-stone-800 font-semibold text-sm">{fmt(item.amount)}</span>
              {onDelete && (
                <button
                  onClick={() => onDelete(item.id)}
                  className="opacity-0 group-hover:opacity-100 text-stone-300 hover:text-rose-400 transition-all"
                >
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
