// src/components/checklist/ChecklistItem.jsx
import { useState } from "react";
import { Trash2, Check } from "lucide-react";

export default function ChecklistItem({ item, onToggle, onDelete }) {
  const [pending, setPending] = useState(false);

  const handleToggle = async () => {
    setPending(true);
    try { await onToggle?.(item.id, !item.isCompleted); }
    finally { setPending(false); }
  };

  return (
    <div
      className={`flex items-center gap-3 px-3 py-2.5 rounded-xl group transition-all duration-150 ${
        item.isCompleted ? "opacity-60" : "hover:bg-stone-50/80"
      }`}
    >
      {/* Checkbox */}
      <button
        onClick={handleToggle}
        disabled={pending}
        className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-all duration-200 ${
          item.isCompleted
            ? "bg-emerald-500 border-emerald-500 scale-95"
            : "border-stone-300 hover:border-amber-400"
        } ${pending ? "opacity-50" : ""}`}
      >
        {item.isCompleted && <Check size={11} strokeWidth={3} className="text-white" />}
      </button>

      {/* Label */}
      <span
        className={`flex-1 text-sm transition-all duration-200 ${
          item.isCompleted ? "line-through text-stone-400" : "text-stone-700"
        }`}
      >
        {item.title ?? item.text}
      </span>

      {/* Delete */}
      {onDelete && (
        <button
          onClick={() => onDelete(item.id)}
          className="opacity-0 group-hover:opacity-100 text-stone-300 hover:text-rose-400 transition-all p-0.5 rounded"
        >
          <Trash2 size={13} />
        </button>
      )}
    </div>
  );
}
