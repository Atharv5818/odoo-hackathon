// src/components/trips/TripStatusBadge.jsx
const STATUS_CONFIG = {
  PLANNING:   { label: "Planning",    bg: "bg-amber-100",   text: "text-amber-700",   dot: "bg-amber-400"   },
  UPCOMING:   { label: "Upcoming",    bg: "bg-sky-100",     text: "text-sky-700",     dot: "bg-sky-400"     },
  ONGOING:    { label: "Ongoing",     bg: "bg-emerald-100", text: "text-emerald-700", dot: "bg-emerald-400" },
  COMPLETED:  { label: "Completed",   bg: "bg-stone-100",   text: "text-stone-600",   dot: "bg-stone-400"   },
  CANCELLED:  { label: "Cancelled",   bg: "bg-red-100",     text: "text-red-600",     dot: "bg-red-400"     },
};

export default function TripStatusBadge({ status, size = "md" }) {
  const cfg = STATUS_CONFIG[status] ?? STATUS_CONFIG.PLANNING;
  const sz  = size === "sm" ? "text-xs px-2 py-0.5 gap-1.5" : "text-sm px-3 py-1 gap-2";

  return (
    <span className={`inline-flex items-center rounded-full font-medium ${sz} ${cfg.bg} ${cfg.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
      {cfg.label}
    </span>
  );
}
