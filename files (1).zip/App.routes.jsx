// src/App.jsx — UPDATED ROUTE REGISTRATION SNIPPET
//
// Add these two routes to your existing router.
// The rest of App.jsx (auth routes, dashboard, layout) is unchanged.
//
// ─── ADD THESE IMPORTS ────────────────────────────────────────────────────────

import TripDetail  from "./pages/TripDetail";
import PublicShare from "./pages/PublicShare";

// ─── ADD THESE ROUTES ─────────────────────────────────────────────────────────
//
// Inside your <Routes> block:
//
//   {/* Protected — inside your PrivateRoute / Layout wrapper */}
//   <Route path="/trips/:tripId" element={<TripDetail />} />
//
//   {/* Public — outside the auth wrapper */}
//   <Route path="/share/:slug" element={<PublicShare />} />
//
// Example full structure:
//
//   <Routes>
//     <Route path="/login"  element={<Auth />} />
//     <Route path="/share/:slug" element={<PublicShare />} />   {/* ← PUBLIC */}
//
//     <Route element={<PrivateRoute />}>
//       <Route element={<Layout />}>
//         <Route path="/dashboard"          element={<Dashboard />} />
//         <Route path="/trips/:tripId"       element={<TripDetail />} />  {/* ← PROTECTED */}
//       </Route>
//     </Route>
//   </Routes>
