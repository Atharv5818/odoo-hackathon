// src/components/checklist/ChecklistGroup.jsx
import { useState } from "react";
import { Plus, ChevronDown } from "lucide-react";
import ChecklistItem from "./ChecklistItem";

function ProgressRing({ pct, size = 32 }) {
  const r   = (size - 4) / 2;
  const cir = 2 * Math.PI * r;
  const off = cir - (pct / 100) * cir;
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#e7e5e4" strokeWidth={3} />
      <circle
        cx={size / 2} cy={size / 2} r={r}
        fill="none"
        stroke={pct === 100 ? "#10b981" : "#f59e0b"}
        strokeWidth={3}
        strokeDasharray={cir}
        strokeDashoffset={off}
        strokeLinecap="round"
        style={{ transition: "stroke-dashoffset 0.4s ease" }}
      />
    </svg>
  );
}

export default function ChecklistGroup({ group, onToggle, onDelete, onAddItem }) {
  const [expanded,    setExpanded]    = useState(true);
  const [adding,      setAdding]      = useState(false);
  const [newTitle,    setNewTitle]    = useState("");
  const [addLoading,  setAddLoading]  = useState(false);

  const items     = group.items ?? [];
  const done      = items.filter((i) => i.isCompleted).length;
  const pct       = items.length ? Math.round((done / items.length) * 100) : 0;

  const handleAdd = async () => {
    const trimmed = newTitle.trim();
    if (!trimmed) return;
    setAddLoading(true);
    try {
      await onAddItem?.(group.id, trimmed);
      setNewTitle("");
      setAdding(false);
    } finally {
      setAddLoading(false);
    }
  };

  return (
    <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl overflow-hidden">
      {/* Group header */}
      <button
        onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-stone-50/60 transition-colors"
      >
        <div className="flex items-center gap-3">
          <ProgressRing pct={pct} />
          <div className="text-left">
            <p className="text-stone-800 font-semibold text-sm">{group.title ?? group.name}</p>
            <p className="text-xs text-stone-400">{done} / {items.length} complete</p>
          </div>
        </div>
        <ChevronDown
          size={16}
          className={`text-stone-400 transition-transform duration-200 ${expanded ? "rotate-180" : ""}`}
        />
      </button>

      {expanded && (
        <div className="px-2 pb-2">
          {items.length === 0 && !adding && (
            <p className="text-stone-300 text-xs text-center py-4">No items yet</p>
          )}

          {items.map((item) => (
            <ChecklistItem
              key={item.id}
              item={item}
              onToggle={onToggle}
              onDelete={onDelete}
            />
          ))}

          {/* Add item input */}
          {adding ? (
            <div className="flex items-center gap-2 px-3 py-2">
              <input
                type="text"
                className="flex-1 text-sm bg-stone-50 border border-stone-200 rounded-lg px-3 py-1.5 focus:outline-none focus:border-amber-300"
                placeholder="New item…"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleAdd()}
                autoFocus
              />
              <button
                onClick={handleAdd}
                disabled={!newTitle.trim() || addLoading}
                className="bg-amber-500 hover:bg-amber-600 disabled:opacity-40 text-white text-xs px-3 py-1.5 rounded-lg transition-colors"
              >
                Add
              </button>
              <button onClick={() => { setAdding(false); setNewTitle(""); }} className="text-stone-400 hover:text-stone-600 text-xs">
                Cancel
              </button>
            </div>
          ) : (
            <button
              onClick={() => setAdding(true)}
              className="flex items-center gap-1.5 w-full px-3 py-2 text-xs text-stone-400 hover:text-amber-600 hover:bg-amber-50/60 rounded-xl transition-colors"
            >
              <Plus size={13} />
              Add item
            </button>
          )}
        </div>
      )}
    </div>
  );
}
