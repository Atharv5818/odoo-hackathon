// src/components/trips/TripOverviewStats.jsx
import { MapPin, Calendar, Clock, Users } from "lucide-react";

function StatCard({ icon: Icon, label, value, sub }) {
  return (
    <div className="bg-white/60 backdrop-blur-sm border border-stone-200/80 rounded-2xl px-5 py-4 flex items-start gap-4">
      <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center flex-shrink-0">
        <Icon size={18} className="text-amber-600" />
      </div>
      <div>
        <p className="text-xs text-stone-400 font-medium uppercase tracking-wider mb-0.5">{label}</p>
        <p className="text-stone-800 font-semibold text-sm leading-tight">{value}</p>
        {sub && <p className="text-xs text-stone-400 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

export default function TripOverviewStats({ trip }) {
  const start   = trip.startDate ? new Date(trip.startDate) : null;
  const end     = trip.endDate   ? new Date(trip.endDate)   : null;
  const nights  = start && end ? Math.round((end - start) / 86400000) : null;

  const fmt = (d) =>
    d?.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });

  const daysUntil = start
    ? Math.max(0, Math.round((start - Date.now()) / 86400000))
    : null;

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      <StatCard
        icon={MapPin}
        label="Destination"
        value={trip.destination ?? "—"}
      />
      <StatCard
        icon={Calendar}
        label="Dates"
        value={start ? `${fmt(start)} → ${fmt(end)}` : "Not set"}
        sub={nights != null ? `${nights} nights` : undefined}
      />
      <StatCard
        icon={Clock}
        label="Departs in"
        value={daysUntil != null ? `${daysUntil} days` : "—"}
        sub={daysUntil === 0 ? "Today!" : undefined}
      />
      <StatCard
        icon={Users}
        label="Travelers"
        value={trip.participantCount ?? trip._count?.participants ?? "1"}
        sub="participants"
      />
    </div>
  );
}
