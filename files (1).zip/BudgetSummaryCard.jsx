// src/components/budget/BudgetSummaryCard.jsx
import { DollarSign, TrendingUp, TrendingDown, Wallet } from "lucide-react";

function MetricTile({ icon: Icon, label, value, accent = "amber", sub }) {
  const colors = {
    amber:   { ring: "bg-amber-50",   icon: "text-amber-600"   },
    emerald: { ring: "bg-emerald-50", icon: "text-emerald-600" },
    rose:    { ring: "bg-rose-50",    icon: "text-rose-600"    },
    sky:     { ring: "bg-sky-50",     icon: "text-sky-600"     },
  };
  const c = colors[accent] ?? colors.amber;

  return (
    <div className="flex items-center gap-3">
      <div className={`w-9 h-9 rounded-xl ${c.ring} flex items-center justify-center flex-shrink-0`}>
        <Icon size={16} className={c.icon} />
      </div>
      <div>
        <p className="text-xs text-stone-400 font-medium uppercase tracking-wider">{label}</p>
        <p className="text-stone-800 font-bold text-base leading-tight">{value}</p>
        {sub && <p className="text-xs text-stone-400">{sub}</p>}
      </div>
    </div>
  );
}

export default function BudgetSummaryCard({ totalBudget, totalSpent, currency = "USD" }) {
  const remaining   = (totalBudget ?? 0) - (totalSpent ?? 0);
  const pct         = totalBudget ? Math.min(100, Math.round((totalSpent / totalBudget) * 100)) : 0;
  const overBudget  = remaining < 0;

  const fmt = (n) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency, maximumFractionDigits: 0 }).format(n ?? 0);

  return (
    <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl p-5">
      <h3 className="text-stone-700 font-semibold text-sm mb-4 flex items-center gap-2">
        <Wallet size={15} className="text-amber-500" />
        Budget Overview
      </h3>

      <div className="grid grid-cols-3 gap-4 mb-5">
        <MetricTile icon={DollarSign}   label="Total Budget" value={fmt(totalBudget)}  accent="sky"     />
        <MetricTile icon={TrendingUp}   label="Spent"        value={fmt(totalSpent)}   accent={overBudget ? "rose" : "amber"} />
        <MetricTile icon={TrendingDown} label="Remaining"    value={fmt(remaining)}    accent={overBudget ? "rose" : "emerald"} />
      </div>

      {/* Progress bar */}
      <div>
        <div className="flex justify-between text-xs text-stone-400 mb-1.5">
          <span>{pct}% used</span>
          <span>{overBudget ? "Over budget!" : `${100 - pct}% remaining`}</span>
        </div>
        <div className="h-2.5 bg-stone-100 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              overBudget ? "bg-rose-400" : pct > 80 ? "bg-amber-400" : "bg-emerald-400"
            }`}
            style={{ width: `${Math.min(100, pct)}%` }}
          />
        </div>
      </div>
    </div>
  );
}
