// src/components/notes/NoteCard.jsx
import { useState } from "react";
import { Trash2, Pencil, Check, X } from "lucide-react";

export default function NoteCard({ note, onDelete, onUpdate }) {
  const [editing, setEditing]   = useState(false);
  const [content, setContent]   = useState(note.content ?? "");
  const [saving, setSaving]     = useState(false);

  const fmt = (d) =>
    new Date(d).toLocaleDateString("en-US", {
      month: "short", day: "numeric", hour: "2-digit", minute: "2-digit",
    });

  const handleSave = async () => {
    if (!content.trim() || content === note.content) { setEditing(false); return; }
    setSaving(true);
    try {
      await onUpdate?.(note.id, { content: content.trim() });
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    setContent(note.content ?? "");
    setEditing(false);
  };

  return (
    <div className="bg-white/70 backdrop-blur-sm border border-stone-200/80 rounded-2xl p-4 group hover:shadow-md hover:-translate-y-0.5 transition-all duration-200">
      {editing ? (
        <div>
          <textarea
            className="w-full text-sm text-stone-700 bg-transparent resize-none focus:outline-none leading-relaxed min-h-[80px]"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            autoFocus
          />
          <div className="flex items-center justify-end gap-2 mt-2 pt-2 border-t border-stone-100">
            <button onClick={handleCancel} className="text-stone-400 hover:text-stone-600 p-1 rounded-lg hover:bg-stone-100 transition-colors">
              <X size={14} />
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex items-center gap-1 bg-amber-500 hover:bg-amber-600 text-white text-xs px-3 py-1.5 rounded-lg transition-colors disabled:opacity-50"
            >
              <Check size={12} />
              {saving ? "Saving…" : "Save"}
            </button>
          </div>
        </div>
      ) : (
        <>
          <p className="text-stone-700 text-sm leading-relaxed whitespace-pre-wrap">{note.content}</p>
          <div className="flex items-center justify-between mt-3 pt-2 border-t border-stone-100">
            <p className="text-xs text-stone-400">{fmt(note.updatedAt ?? note.createdAt)}</p>
            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={() => setEditing(true)}
                className="text-stone-300 hover:text-amber-500 p-1 rounded-lg hover:bg-amber-50 transition-colors"
              >
                <Pencil size={13} />
              </button>
              <button
                onClick={() => onDelete?.(note.id)}
                className="text-stone-300 hover:text-rose-400 p-1 rounded-lg hover:bg-rose-50 transition-colors"
              >
                <Trash2 size={13} />
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
