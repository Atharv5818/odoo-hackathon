// src/utils/slugify.js
import { randomBytes } from "crypto";

/**
 * Convert a string into a URL-safe slug.
 * e.g. "My Trip to Japan! 2025" → "my-trip-to-japan-2025"
 *
 * @param {string} str
 */
export function slugify(str) {
  return str
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")   // remove non-word chars (keep hyphens)
    .replace(/[\s_]+/g, "-")    // spaces/underscores → hyphen
    .replace(/-+/g, "-")        // collapse multiple hyphens
    .slice(0, 60);              // cap length
}

/**
 * Generate a unique, collision-resistant share slug.
 * Format: <slugified-title>-<6-char random suffix>
 *
 * @param {string} title - trip title used as human-readable prefix
 */
export function generateShareSlug(title = "trip") {
  const base   = slugify(title) || "trip";
  const suffix = randomBytes(4).toString("hex"); // 8 hex chars → trim to 6
  return `${base}-${suffix.slice(0, 6)}`;
}
